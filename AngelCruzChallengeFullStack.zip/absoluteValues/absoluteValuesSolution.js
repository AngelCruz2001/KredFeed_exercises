
export const getAbsoluteValues = (arr) => {
  return arr.map((element) => Math.abs(element)); 
}